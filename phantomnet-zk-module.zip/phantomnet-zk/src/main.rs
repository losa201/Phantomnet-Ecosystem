fn main() {
    phantomnet_zk::demo();
}
